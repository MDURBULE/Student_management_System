package Student_manager;

//imports
import Connection_cp.cp;
import student.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class Student_manager {
    public Boolean addStudent(Student  st){
        boolean flag = false;
        try{
            Connection con = cp.createConnection();
            String query = "insert into students(sname,cname,mobile_no) values(?,?,?)";
            PreparedStatement pt = con.prepareStatement(query);

            pt.setString(1,st.getName());
            pt.setString(2,st.getCollege_name());
            pt.setString(3, st.getMobile_no());

            pt.executeUpdate();
            flag = true;

        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }
    public void showStudent(){
        try{
            Connection con = cp.createConnection();
            String query = "select * from students; ";
            PreparedStatement pt = con.prepareStatement(query);

            ResultSet rs = pt.executeQuery();
            while (rs.next()){
                System.out.println("id : "+rs.getInt(1));
                System.out.println("full name : "+rs.getNString(2));
                System.out.println("college name : "+rs.getNString(3));
                System.out.println("mobile no : "+rs.getNString(4));
                System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public boolean deleteStudent(int id){
        boolean flag = false;
        try {
            Connection con = cp.createConnection();
            String query = "delete from students where sid = ?";
            PreparedStatement pt = con.prepareStatement(query);

            pt.setInt(1,id);
            pt.executeUpdate();
            flag = true;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }
}
