package student;

public class Student{
private int id;
private String name;
private  String college_name;
private String mobile_no;

public Student(String name, String college_name, String mobile_no) {
        this.name = name;
        this.college_name = college_name;
        this.mobile_no = mobile_no;
        }

public Student() {
        }

public int getId() {
        return id;
        }

public void setId(int id) {
        this.id = id;
        }

public String getName() {
        return name;
        }

public void setName(String name) {
        this.name = name;
        }

public String getCollege_name() {
        return college_name;
        }

public void setCollege_name(String college_name) {
        this.college_name = college_name;
        }

public String getMobile_no() {
        return mobile_no;
        }

public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
        }

@java.lang.Override
public java.lang.String toString() {
        return "Student{" +
        "id=" + id +
        ", name='" + name + '\'' +
        ", college_name='" + college_name + '\'' +
        ", mobile_no=" + mobile_no +
        '}';
        }


}
